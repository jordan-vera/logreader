<?php script($_['appId'], ['../build/main']); ?>
<?php style($_['appId'], ['../build/main']); ?>
<?php style($_['appId'], ['app']); ?>
<div id="searchresults" style="display: none"></div>
<div id="logreader-root" data-inline-settings="<?php echo $_['inline-settings'];?>"/>
