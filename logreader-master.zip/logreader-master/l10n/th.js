OC.L10N.register(
    "logreader",
    {
    "Copy" : "คัดลอก",
    "Time" : "เวลา"
},
"nplurals=1; plural=0;");
