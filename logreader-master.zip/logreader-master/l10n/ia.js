OC.L10N.register(
    "logreader",
    {
    "Copy" : "Copiar",
    "Time" : "Tempore"
},
"nplurals=2; plural=(n != 1);");
