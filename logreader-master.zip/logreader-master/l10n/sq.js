OC.L10N.register(
    "logreader",
    {
    "Error parsing log" : "Gabim në analizimin e regjistrit",
    "Copy" : "Kopjo",
    "No server logs" : "Nuk ka regjistra të serverit",
    "One or more entries are hidden by the log level filter" : "Një ose më shumë hryje janë fshehur nga filtri i nivelit të regjistrit",
    "Everything is working fine" : "Çdo gjë po funksionon mirë",
    "Level" : "Nivel",
    "App" : "Aplikacion",
    "Message" : "Mesazh",
    "Time" : "Kohë",
    "Log levels" : "Nivelet e hyrjes",
    "Log content" : "Përmbajtja e hyrjes",
    "Live update" : "Përditësim live",
    "Download logs" : "Regjistrimet e shkarkuara",
    "Logging" : "Duke hyrë",
    "Log Reader" : "Lexuesi i Regjistrit"
},
"nplurals=2; plural=(n != 1);");
