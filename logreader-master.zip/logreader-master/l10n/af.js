OC.L10N.register(
    "logreader",
    {
    "Copy" : "Kopieer",
    "App" : "Toep",
    "Time" : "Tyd"
},
"nplurals=2; plural=(n != 1);");
