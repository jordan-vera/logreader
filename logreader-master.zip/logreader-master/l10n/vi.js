OC.L10N.register(
    "logreader",
    {
    "Copy" : "Sao chép",
    "Level" : "Cấp độ",
    "Time" : "Thời gian"
},
"nplurals=1; plural=0;");
