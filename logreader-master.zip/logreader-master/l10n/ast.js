OC.L10N.register(
    "logreader",
    {
    "Error parsing log" : "Fallu analizando'l rexistru",
    "Copy" : "Copiar",
    "No server logs" : "Nun hai rexistros del sirvidor",
    "Everything is working fine" : "Too ta funcionando bien",
    "App" : "Aplicación",
    "Message" : "Menxase",
    "Time" : "Hora",
    "Log levels" : "Niveles de rexistru",
    "Log content" : "Conteníu del rexistru",
    "Live update" : "Anovamientu en direuto"
},
"nplurals=2; plural=(n != 1);");
