OC.L10N.register(
    "logreader",
    {
    "Copy" : "Salin",
    "App" : "Apl",
    "Message" : "Pesan",
    "Time" : "Waktu"
},
"nplurals=1; plural=0;");
