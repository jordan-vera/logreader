OC.L10N.register(
    "logreader",
    {
    "Copy" : "Copiar",
    "Level" : "Nível",
    "App" : "Aplicação",
    "Message" : "Mensagem",
    "Time" : "Tempo",
    "Download logs" : "Transferir registos",
    "Logging" : "Registos"
},
"nplurals=2; plural=(n != 1);");
