OC.L10N.register(
    "logreader",
    {
    "App" : "Applikasjon",
    "Time" : "Tid"
},
"nplurals=2; plural=(n != 1);");
