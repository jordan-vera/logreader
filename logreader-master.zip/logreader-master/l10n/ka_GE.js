OC.L10N.register(
    "logreader",
    {
    "Error parsing log" : "შეცდომა ლოგის გარჩევისას",
    "Copy" : "კოპირება",
    "No server logs" : "სერვერის ლოგები არაა",
    "One or more entries are hidden by the log level filter" : "ლოგის დონის ფილტრით ერთი ან მეტი შენატანი დამალულია",
    "Everything is working fine" : "ყველაფერი კარგად მუშაობს",
    "Level" : "დონე",
    "App" : "აპლიკაცია",
    "Message" : "წერილი",
    "Time" : "დრო",
    "Log levels" : "ლოგის დონეები",
    "Log content" : "ლოგის მოცულობა",
    "Live update" : "ცოცხალი განახლება",
    "Download logs" : "ლოგების გადმოწერა",
    "Logging" : "იწერება ლოგი",
    "Log Reader" : "ლოგის მკითხველი"
},
"nplurals=2; plural=(n!=1);");
