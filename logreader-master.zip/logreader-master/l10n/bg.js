OC.L10N.register(
    "logreader",
    {
    "Copy" : "Копиране",
    "Level" : "Ниво",
    "App" : "Приложение",
    "Message" : "Съобщение",
    "Time" : "Време"
},
"nplurals=2; plural=(n != 1);");
