OC.L10N.register(
    "logreader",
    {
    "Error parsing log" : "Kļūda analizējot žurnālus",
    "Copy" : "Kopēt",
    "No server logs" : "Nav servera žurnālierakstu",
    "One or more entries are hidden by the log level filter" : "Vēl viens ieraksts ir slēpts žurnālierakstu līmeņa filtrā",
    "Everything is working fine" : "Viss darbojas labi",
    "App" : "Lietotne",
    "Message" : "Ziņojums",
    "Time" : "Laiks",
    "Download logs" : "Lejupielādēt žurnālierakstu",
    "Logging" : "Žurnalēšana",
    "Log Reader" : "Žurnālierakstu lasītājs"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
