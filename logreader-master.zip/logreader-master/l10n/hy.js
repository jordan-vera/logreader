OC.L10N.register(
    "logreader",
    {
    "Copy" : "պատճենահանել",
    "Time" : "Ժամ"
},
"nplurals=2; plural=(n != 1);");
