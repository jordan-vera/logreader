OC.L10N.register(
    "logreader",
    {
    "Copy" : "Хуулах",
    "Level" : "түвшин",
    "App" : "Аппликэйшин",
    "Time" : "Цаг"
},
"nplurals=2; plural=(n != 1);");
